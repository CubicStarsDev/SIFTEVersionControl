﻿using System;
using System.Diagnostics;

public static class W10Activator
{
    static Dictionary<int, string> keys_versions = new Dictionary<int, string>()
    {
        {0, "TX9XD-98N7V-6WMQ6-BX7FG-H8Q99"},
        {1, "3KHY7-WNT83-DGQKR-F7HPR-844BM"},
        {2, "7HNRX-D7KGG-3K4RQ-4WPJ4-YTDFH"},
        {3, "W269N-WFGWX-YVC9B-4J6C9-T83GX"},
        {4, "MH37W-N47XK-V7XM9-C7227-GCQG9"},
        {5, "NRG8B-VKK3Q-CXVCJ-9G2XF-6Q84J"},
        {6, "9FNHH-K3HBT-3W4TD-6383H-6XYWF"},
        {7, "NW6C2-QMPVW-D7KKK-3GKT6-VCFB2"},
        {8, "2WH4N-8QGBV-H22JP-CT43Q-MDWWJ"},
        {9, "6TP4R-GNPTD-KYYHQ-7B7DP-J447Y"},
        {10, "YVWGF-BXNMC-HTQYQ-CPQ99-66QFC"},
        {11, "NPPR9-FWDCX-D2C8J-H872K-2YT43"},
        {12, "YYVX9-NTFWV-6MDM3-9PT4T-4M68B"},
        {13, "44RPN-FTY23-9VTTB-MP9BX-T84FV"},
        {14, "DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4"},
        {15, "FWN7H-PF93Q-4GGP8-M8RF3-MDWWW"},
        {16, "WNMTR-4C88C-JK8YV-HQ7T2-76DF9"},
        {17, "2F77B-TNFGY-69QQF-B8YKP-D69TJ"},
        {18, "DCPHK-NFMTC-H88MJ-PFHPY-QJ4BJ"},
        {19, "QFFDN-GRT3P-VKWWX-X7T3R-8B639"},
        {20, "M7XTQ-FN8P6-TTKYV-9D4CC-J462D"},
        {21, "92NFX-8DJQP-P6BBQ-THF9C-7CG2H"},
        {22, "CB7KF-BWN84-R7R2Y-793K2-8XDDG"},
        {23, "WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY"},
        {24, "JCKRF-N37P4-C2D82-9YXRT-4M63B"},
        {25, "WMDGN-G9PQG-XVVXX-R3X43-63DFG"},
        {26, "N69G4-B89J2-4G8F4-WWYCC-J464C"},
        {27, "WVDHN-86M7X-466P6-VHXV7-YY726"}
    };

    static string[] versions = new string[]
    {
        "Windows 10 Home",
        "Windows 10 Home N",
        "Windows 10 Home Single Language",
        "Windows 10 Pro",
        "Windows 10 Pro N",
        "Windows 10 Pro for Workstations",
        "Windows 10 Pro N for Workstations",
        "Windows 10 Education",
        "Windows 10 Education N",
        "Windows 10 Pro Education",
        "Windows 10 Pro Education N",
        "Windows 10 Enterprise",
        "Windows 10 Enterprise G",
        "Windows 10 Enterprise G N",
        "Windows 10 Enterprise N",
        "Windows 10 Enterprise S",
        "Windows 10 Enterprise 2015 LTSB",
        "Windows 10 Enterprise 2015 LTSB N",
        "Windows 10 Enterprise LTSC 2019/2021",
        "Windows 10 Enterprise N LTSC 2019/2021",
        "Windows Server 2016 Datacenter",
        "Windows Server 2016 Standard",
        "Windows Server 2016 Essentials",
        "Windows Server 2019 Datacenter",
        "Windows Server 2019 Standard",
        "Windows Server 2019 Essentials"
    };

    static bool canExecuteProcess = true;


    static void Main()
    {
        print("hola y bienvenido a 'Windows 10 Activator'!");
        print("Presione cualquier tecla para continuar");
        Console.ReadKey();
        Console.Clear();
        for(int i = 0;  i < versions.Length; i++)
        {
            print($"{i + 1}- {versions[i]}");
        }
        print("\nPorfavor seleccione su version: ");
        int selectedVersion = Convert.ToInt32(Console.ReadLine().Trim());
        Thread.Sleep(1000);
        Console.Clear();
        Activate(selectedVersion - 1);
    }

    static void print(object content)
    {
        Console.WriteLine(content);
    }

    static void ExecuteCommand(string arg)
    {
        while(!canExecuteProcess)
        {
            //Do nothing
        }
        Process process = new Process();
        // Set the StartInfo.FileName property to the path of the CMD executable.
        process.StartInfo.FileName = "cmd.exe";
        // Set the StartInfo.Arguments property to the CMD command that you want to execute.
        process.StartInfo.Arguments = $"/c {arg}";
        // Start the process.
        process.Start();
        // Wait for the process to finish.
        process.WaitForExit();
        canExecuteProcess = true;
    }

    static void Activate(int version)
    {
        ExecuteCommand($"slmgr /ipk {keys_versions[version]}");
        ExecuteCommand("slmgr /skms kms.digiboy.ir");
        ExecuteCommand("slmgr /ato");
        Console.Clear();
        if(canExecuteProcess)
        {
            print("Su windows se ha activado satisfactoriamente");
            Thread.Sleep(500);
            print("Toque cualquier tecla para salir");
            Console.ReadKey();
        }
    }
}